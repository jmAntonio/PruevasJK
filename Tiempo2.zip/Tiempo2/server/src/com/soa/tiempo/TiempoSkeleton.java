/**
 * TiempoSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.9  Built on : Nov 16, 2018 (12:05:37 GMT)
 */
package com.soa.tiempo;

/**
 *  TiempoSkeleton java skeleton for the axisService
 */
public class TiempoSkeleton {
    /**
     * Auto generated method signature
     *
     * @param reqJoseAntonioJuarezMendoza
     * @return resJoseAntonioJuarezMendoza
     */
    public com.soa.tiempo.ResJoseAntonioJuarezMendoza tiempoOperation(
        com.soa.tiempo.ReqJoseAntonioJuarezMendoza reqJoseAntonioJuarezMendoza) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#tiempoOperation");
    }
}
