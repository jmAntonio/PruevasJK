package com.soa.tiempo;

import static org.junit.Assert.*;

import java.rmi.RemoteException;

import org.junit.Assert;
import org.junit.Test;

import com.soa.tiempo.TiempoStub;
import com.soa.tiempo.TiempoStub.ReqJoseAntonioJuarezMendoza;
import com.soa.tiempo.TiempoStub.ResJoseAntonioJuarezMendoza;

public class Tiempo {

    @Test
    public void test() throws RemoteException {
        TiempoStub stub = new TiempoStub();
        ReqJoseAntonioJuarezMendoza request = new ReqJoseAntonioJuarezMendoza();
        request.setTiempo1("20:00:00");
        request.setTiempo2("22:30:00");
        ResJoseAntonioJuarezMendoza tiempoOperation = stub.tiempoOperation(request);
        Assert.assertEquals(9000, tiempoOperation.getDuracion() ); 
    }

}
