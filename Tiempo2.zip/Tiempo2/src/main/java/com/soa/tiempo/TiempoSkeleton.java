/**
 * TiempoSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.9  Built on : Nov 16, 2018 (12:05:37 GMT)
 */
package com.soa.tiempo;

import com.soa.tiempo.ResJoseAntonioJuarezMendoza;

/**
 *  TiempoSkeleton java skeleton for the axisService
 */
public class TiempoSkeleton {
    /**
     * Auto generated method signature
     *
     * @param reqJoseAntonioJuarezMendoza
     * @return resJoseAntonioJuarezMendoza
     */
    public com.soa.tiempo.ResJoseAntonioJuarezMendoza tiempoOperation(
        com.soa.tiempo.ReqJoseAntonioJuarezMendoza reqJoseAntonioJuarezMendoza) {
        //TODO : fill this with the necessary business logic
        String hora1 = reqJoseAntonioJuarezMendoza.getTiempo1();
        String hora2 = reqJoseAntonioJuarezMendoza.getTiempo2();

        String[] h1 = hora1.split(":");
        String[] h2 = hora2.split(":");
        int resto = 0;

        int segundo1 = Integer.parseInt(h2[2]);
        int segundo2 = Integer.parseInt(h1[2]);
        int resSegundo=0;
        
        resSegundo=segundo1-segundo2;

        int minuto1 = Integer.parseInt(h2[1]);
        int minuto2 = Integer.parseInt(h1[1]);
        int resMinuto=0;
        
        resMinuto=(minuto1-minuto2)*60;
        
        
        int hrs1 = Integer.parseInt(h2[0]);
        int hrs2 = Integer.parseInt(h1[0]);
        int resHorao=0;
        
        resHorao=(hrs1-hrs2)*60*60;
        
        int duracion= resHorao+resMinuto+resSegundo;
        ResJoseAntonioJuarezMendoza obj = new ResJoseAntonioJuarezMendoza();
        obj.setDuracion(duracion);
        return obj;
    }
}
